# PGNest – Student Accommodation Website

A fully functional student PG (Paying Guest) accommodation platform built with
HTML, CSS, Bootstrap-compatible layout, Vanilla JS, AJAX, PHP, and MySQL.

---

## 📁 Project Structure

```
pgnest/
├── index.html              ← Main page (open this)
├── css/
│   └── style.css           ← All styles
├── js/
│   └── app.js              ← Frontend logic + AJAX calls
├── php/
│   ├── config.php          ← DB connection + helpers
│   ├── properties.php      ← Property listing & detail API
│   ├── auth.php            ← Login / Signup / Logout API
│   └── interest.php        ← Mark/unmark interest API
├── sql/
│   └── schema.sql          ← Database schema + seed data
└── README.md
```

---

## ⚡ Quick Start

### Option A – Without PHP (Demo Mode)
Just open `index.html` in your browser.
- All 12 properties load from built-in demo data
- Filters, search, sort, shortlist all work
- Login/Interest require PHP backend

---

### Option B – Full Stack with XAMPP

#### Step 1 — Install XAMPP
Download from https://www.apachefriends.org and install.
Start **Apache** and **MySQL** from the XAMPP Control Panel.

#### Step 2 — Place project files
Copy the entire `pgnest/` folder into:
```
C:\xampp\htdocs\pgnest\       (Windows)
/Applications/XAMPP/htdocs/pgnest/  (Mac)
```

#### Step 3 — Create the database
Open http://localhost/phpmyadmin in your browser.
Click **"New"** → name it `pgnest` → click **Create**.
Then click the `pgnest` database → **Import** tab →
Choose file: `sql/schema.sql` → click **Go**.

#### Step 4 — Configure database credentials
Open `php/config.php` and update if needed:
```php
define('DB_USER', 'root');   // Your MySQL username
define('DB_PASS', '');       // Your MySQL password (blank for XAMPP default)
```

#### Step 5 — Open the site
Visit: http://localhost/pgnest/

#### Step 6 — Demo login
- Email: `demo@pgnest.com`
- Password: `password123`

---

## 🔧 Tech Stack

| Layer      | Technology |
|------------|------------|
| Frontend   | HTML5, CSS3, Vanilla JS |
| Icons      | Tabler Icons (CDN) |
| Backend    | PHP 8+ |
| Database   | MySQL 5.7+ / MariaDB |
| AJAX       | Fetch API (no jQuery needed) |

---

## ✨ Features

- ✅ Responsive property listing grid
- ✅ AJAX search (debounced, no page reload)
- ✅ Filter by city, budget, gender
- ✅ Sort by rating, price, name
- ✅ Property detail modal with amenities
- ✅ User signup & login (PHP sessions)
- ✅ Mark / unmark interest (AJAX)
- ✅ Shortlist properties (local + DB)
- ✅ Toast notifications
- ✅ Keyboard accessible
- ✅ Mobile responsive
- ✅ Graceful fallback (works without PHP)

---

## 🗄️ Database Schema

| Table               | Purpose                         |
|---------------------|---------------------------------|
| users               | Registered user accounts        |
| properties          | PG property listings            |
| amenities           | Amenity catalog                 |
| property_amenities  | Junction: property ↔ amenity    |
| interested_users    | Junction: user ↔ property       |

---

## 🚀 Deployment (Live Server)

1. Upload all files to your hosting via FTP (FileZilla)
2. Create a MySQL database in cPanel → MySQL Databases
3. Import `sql/schema.sql` via cPanel → phpMyAdmin
4. Update `php/config.php` with your hosting DB credentials
5. Visit your domain!

Recommended free hosts: InfinityFree, 000webhost, Render (with PHP)

---

## 📝 Deliverables Checklist (Internshala)

- [x] Live project URL (after deployment)
- [x] GitHub repository (push this folder)
- [x] Database schema file → `sql/schema.sql`
- [x] Property Listing Page → `index.html`
- [x] Property Detail → click any card
- [x] AJAX interaction → search / interest toggle
- [x] Project document → this README

---

## 💡 Tips

- The site **works without a server** — just open index.html
- With XAMPP, it fetches **live data from MySQL** via PHP
- All AJAX calls gracefully fall back to demo data if PHP fails
- Passwords are hashed with bcrypt (industry standard)
