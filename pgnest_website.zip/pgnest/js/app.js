/**
 * PGNest - Main JavaScript (AJAX-driven)
 * Handles: property listing, filtering, auth, interest, shortlist
 */

'use strict';

/* =====================================================
   STATE
   ===================================================== */
const State = {
  properties   : [],
  filtered     : [],
  interestIds  : new Set(),
  shortlistIds : new Set(),
  currentUser  : null,
  genderFilter : '',
  sortMode     : 'rating',
  loading      : false,
};

/* =====================================================
   API HELPERS
   ===================================================== */
const API = {
  base: 'php/',

  async get(file, params = {}) {
    const qs = new URLSearchParams(params).toString();
    const res = await fetch(`${this.base}${file}${qs ? '?' + qs : ''}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  },

  async post(file, action, body = {}) {
    const res = await fetch(`${this.base}${file}?action=${action}`, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(body),
    });
    return res.json();
  },
};

/* =====================================================
   UTILITY HELPERS
   ===================================================== */
function qs(sel, ctx = document)  { return ctx.querySelector(sel); }
function qsa(sel, ctx = document) { return [...ctx.querySelectorAll(sel)]; }
function el(tag, cls, html = '') {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html) e.innerHTML = html;
  return e;
}

function toast(msg, duration = 2800) {
  const t = qs('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._tid);
  t._tid = setTimeout(() => t.classList.remove('show'), duration);
}

function setLoading(show) {
  State.loading = show;
  qs('#loading-wrap').classList.toggle('hidden', !show);
  qs('#prop-grid').classList.toggle('hidden', show);
}

function starsHTML(rating) {
  let html = '';
  for (let i = 1; i <= 5; i++) {
    html += `<span class="${i <= Math.round(rating) ? 'star-fill' : 'star-empty'}">★</span>`;
  }
  html += `<span class="val">${rating.toFixed(1)}</span>`;
  return html;
}

function priceFormat(n) {
  return '₹' + n.toLocaleString('en-IN');
}

function badgeClass(gender) {
  return gender === 'Girls' ? 'badge-girls' : gender === 'Boys' ? 'badge-boys' : 'badge-coed';
}

/* =====================================================
   MODAL HELPERS
   ===================================================== */
function openModal(id) {
  const overlay = qs(`#${id}`);
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  const overlay = qs(`#${id}`);
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}

/* =====================================================
   RENDER PROPERTY CARDS
   ===================================================== */
function renderCards() {
  const grid    = qs('#prop-grid');
  const empty   = qs('#empty-state');
  const counter = qs('#result-count');
  counter.textContent = State.filtered.length;

  if (!State.filtered.length) {
    grid.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  grid.innerHTML = State.filtered.map(p => {
    const amenityPills = p.amenities.slice(0, 3).map(a =>
      `<span class="pill">${a.icon}${a.name}</span>`
    ).join('') + (p.amenities.length > 3 ? `<span class="pill">+${p.amenities.length - 3}</span>` : '');

    const isInterested = State.interestIds.has(p.id);
    const favIcon      = isInterested ? '❤️' : '🤍';

    return `
      <article class="prop-card" data-id="${p.id}" tabindex="0" role="button"
               aria-label="View details for ${p.name}">
        <div class="card-thumb">
          <span aria-hidden="true">${p.image_emoji}</span>
          <span class="card-badge ${badgeClass(p.gender)}">${p.gender}</span>
          <button class="card-fav-btn" data-id="${p.id}"
                  aria-label="${isInterested ? 'Remove interest' : 'Mark interested'}"
                  title="${isInterested ? 'Remove interest' : 'Mark interested'}">
            ${favIcon}
          </button>
        </div>
        <div class="card-body">
          <h3 class="card-title">${p.name}</h3>
          <p class="card-loc">
            <i class="ti ti-map-pin" aria-hidden="true"></i>
            ${p.area}, ${p.city}
          </p>
          <p class="card-price">${priceFormat(p.price)} <small>/month</small></p>
          <div class="amenity-pills">${amenityPills}</div>
          <div class="card-footer">
            <div class="stars">${starsHTML(p.rating)}</div>
          </div>
        </div>
      </article>`;
  }).join('');

  // Card click → detail modal
  qsa('.prop-card').forEach(card => {
    card.addEventListener('click', e => {
      if (e.target.closest('.card-fav-btn')) return;
      openDetailModal(+card.dataset.id);
    });
    card.addEventListener('keydown', e => {
      if (e.key === 'Enter') openDetailModal(+card.dataset.id);
    });
  });

  // Fav button (AJAX toggle)
  qsa('.card-fav-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      toggleInterest(+btn.dataset.id);
    });
  });

  // Update stats
  qs('#stat-interested').textContent = State.interestIds.size;
  qs('#shortlist-count').textContent = State.shortlistIds.size;
}

/* =====================================================
   FILTER + SORT (AJAX)
   ===================================================== */
async function fetchAndRender(showLoader = true) {
  const search = qs('#search-input').value.trim();
  const city   = qs('#filter-city').value;
  const budget = qs('#filter-budget').value;

  if (showLoader) setLoading(true);

  try {
    const res = await API.get('properties.php', {
      action: 'list',
      search, city,
      gender: State.genderFilter,
      budget,
      sort  : State.sortMode,
    });

    if (!res.success) throw new Error(res.message);
    State.filtered = res.data;
    if (showLoader) setLoading(false);
    renderCards();
  } catch (err) {
    if (showLoader) setLoading(false);
    console.error('Fetch error:', err);
    toast('⚠️ Could not load properties. Using demo data.');
    State.filtered = [...State.properties]; // fallback
    renderCards();
  }
}

function setGenderFilter(val, tagEl) {
  State.genderFilter = val;
  qsa('.filter-tag').forEach(t => t.classList.remove('active'));
  tagEl.classList.add('active');
  fetchAndRender();
}

/* =====================================================
   DETAIL MODAL (AJAX)
   ===================================================== */
async function openDetailModal(id) {
  openModal('detail-modal');
  const body = qs('#detail-body');
  body.innerHTML = '<div class="loading-wrap"><div class="spinner"></div> Loading…</div>';

  try {
    const res = await API.get('properties.php', { action: 'detail', id });
    if (!res.success) throw new Error(res.message);
    renderDetailBody(res.data);
  } catch (err) {
    console.error('Detail error:', err);
    // Fallback: find in local state
    const p = State.filtered.find(x => x.id === id) || State.properties.find(x => x.id === id);
    if (p) renderDetailBody(p);
    else body.innerHTML = '<p style="color:red;text-align:center">Could not load details.</p>';
  }
}

function renderDetailBody(p) {
  qs('#detail-modal-title').textContent = p.name;

  const isInterested = State.interestIds.has(p.id);
  const isShortlisted = State.shortlistIds.has(p.id);

  const amenitiesHTML = p.amenities.map(a =>
    `<span class="amenity-chip">${a.icon} ${a.name}</span>`
  ).join('');

  qs('#detail-body').innerHTML = `
    <div class="detail-gallery" aria-label="Property image">${p.image_emoji}</div>
    <p class="detail-desc">${p.description || ''}</p>

    <div class="detail-grid">
      <div class="detail-item">
        <label>Location</label>
        <strong>${p.area}, ${p.city}</strong>
      </div>
      <div class="detail-item">
        <label>Monthly Rent</label>
        <strong>${priceFormat(p.price)}</strong>
      </div>
      <div class="detail-item">
        <label>Gender</label>
        <strong>${p.gender}</strong>
      </div>
      <div class="detail-item">
        <label>Rating</label>
        <strong>${p.rating.toFixed(1)} ★</strong>
      </div>
    </div>

    <p class="section-label">Amenities</p>
    <div class="amenities-wrap">${amenitiesHTML}</div>

    <div class="detail-actions">
      <button class="btn-primary ${isInterested ? 'interested' : ''}"
              id="btn-interest-detail" data-id="${p.id}">
        ${isInterested ? '❤️ Interested' : '🤍 Mark Interested'}
      </button>
      <button class="btn-secondary ${isShortlisted ? 'shortlisted' : ''}"
              id="btn-shortlist-detail" data-id="${p.id}">
        ${isShortlisted ? '🔖 Shortlisted' : '+ Shortlist'}
      </button>
    </div>`;

  qs('#btn-interest-detail').addEventListener('click', () => toggleInterest(p.id, true));
  qs('#btn-shortlist-detail').addEventListener('click', () => toggleShortlist(p.id, true));
}

/* =====================================================
   INTEREST (AJAX)
   ===================================================== */
async function toggleInterest(pid, fromDetail = false) {
  if (!State.currentUser) {
    toast('🔒 Please log in to mark interest');
    openModal('auth-modal');
    return;
  }

  try {
    const res = await API.post('interest.php', 'toggle', { property_id: pid });
    if (!res.success) throw new Error(res.message);

    if (res.interested) {
      State.interestIds.add(pid);
      toast('❤️ Marked as Interested!');
    } else {
      State.interestIds.delete(pid);
      toast('Removed from Interested');
    }

    renderCards();
    if (fromDetail) {
      const btn = qs('#btn-interest-detail');
      if (btn && +btn.dataset.id === pid) {
        btn.textContent = res.interested ? '❤️ Interested' : '🤍 Mark Interested';
        btn.classList.toggle('interested', res.interested);
      }
    }
  } catch (err) {
    // Offline / no-PHP fallback
    if (State.interestIds.has(pid)) {
      State.interestIds.delete(pid);
      toast('Removed from Interested');
    } else {
      State.interestIds.add(pid);
      toast('❤️ Marked as Interested!');
    }
    renderCards();
  }
}

/* =====================================================
   SHORTLIST (client-side, no auth required)
   ===================================================== */
function toggleShortlist(pid, fromDetail = false) {
  if (State.shortlistIds.has(pid)) {
    State.shortlistIds.delete(pid);
    toast('Removed from Shortlist');
  } else {
    State.shortlistIds.add(pid);
    toast('🔖 Added to Shortlist!');
  }
  qs('#shortlist-count').textContent = State.shortlistIds.size;
  renderCards();
  if (fromDetail) {
    const btn = qs('#btn-shortlist-detail');
    if (btn && +btn.dataset.id === pid) {
      const sl = State.shortlistIds.has(pid);
      btn.textContent = sl ? '🔖 Shortlisted' : '+ Shortlist';
      btn.classList.toggle('shortlisted', sl);
    }
  }
}

function openShortlistModal() {
  if (!State.shortlistIds.size) { toast('No properties shortlisted yet.'); return; }
  const ids = [...State.shortlistIds];
  const all = [...State.properties, ...State.filtered];
  const uniq = [...new Map(all.map(p => [p.id, p])).values()];

  qs('#shortlist-modal-body').innerHTML = ids.map(id => {
    const p = uniq.find(x => x.id === id);
    if (!p) return '';
    return `<div class="shortlist-item">
      <span class="shortlist-emoji">${p.image_emoji}</span>
      <div class="shortlist-info">
        <p class="shortlist-name">${p.name}</p>
        <p class="shortlist-sub">${p.area}, ${p.city} · ${priceFormat(p.price)}/mo</p>
      </div>
      <button class="btn-remove" data-id="${p.id}" title="Remove">
        <i class="ti ti-trash" aria-hidden="true"></i>
      </button>
    </div>`;
  }).join('') + '<p style="font-size:12px;color:var(--gray-400);text-align:center;margin-top:1rem">Contact property owners directly after shortlisting.</p>';

  qsa('#shortlist-modal-body .btn-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      toggleShortlist(+btn.dataset.id);
      if (!State.shortlistIds.size) { closeModal('shortlist-modal'); return; }
      openShortlistModal();
    });
  });

  openModal('shortlist-modal');
}

/* =====================================================
   AUTH (AJAX)
   ===================================================== */
function switchAuthTab(tab) {
  qsa('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  qs('#login-form').classList.toggle('hidden', tab !== 'login');
  qs('#signup-form').classList.toggle('hidden', tab !== 'signup');
  qsa('.form-error').forEach(e => e.classList.remove('show'));
}

async function handleLogin(e) {
  e.preventDefault();
  const email = qs('#login-email').value.trim();
  const pass  = qs('#login-pass').value;
  const err   = qs('#login-error');
  err.classList.remove('show');

  if (!email || !pass) { err.textContent = 'Email and password required.'; err.classList.add('show'); return; }

  const btn = qs('#btn-login-submit');
  btn.innerHTML = '<div class="spinner"></div> Logging in…';
  btn.disabled = true;

  try {
    const res = await API.post('auth.php', 'login', { email, password: pass });
    if (!res.success) throw new Error(res.message);
    setUser(res.user);
    closeModal('auth-modal');
    toast(`Welcome back, ${res.user.name.split(' ')[0]}! 👋`);
    loadInterestIds();
  } catch (ex) {
    err.textContent = ex.message || 'Login failed.';
    err.classList.add('show');
  } finally {
    btn.innerHTML = 'Log in';
    btn.disabled = false;
  }
}

async function handleSignup(e) {
  e.preventDefault();
  const name  = qs('#signup-name').value.trim();
  const email = qs('#signup-email').value.trim();
  const phone = qs('#signup-phone').value.trim();
  const pass  = qs('#signup-pass').value;
  const err   = qs('#signup-error');
  err.classList.remove('show');

  if (!name || !email || !pass) { err.textContent = 'Name, email and password required.'; err.classList.add('show'); return; }
  if (pass.length < 6)           { err.textContent = 'Password must be at least 6 characters.'; err.classList.add('show'); return; }

  const btn = qs('#btn-signup-submit');
  btn.innerHTML = '<div class="spinner"></div> Creating…';
  btn.disabled  = true;

  try {
    const res = await API.post('auth.php', 'signup', { name, email, phone, password: pass });
    if (!res.success) throw new Error(res.message);
    setUser(res.user);
    closeModal('auth-modal');
    toast(`Welcome to PGNest, ${res.user.name.split(' ')[0]}! 🎉`);
  } catch (ex) {
    err.textContent = ex.message || 'Signup failed.';
    err.classList.add('show');
  } finally {
    btn.innerHTML = 'Create Account';
    btn.disabled  = false;
  }
}

function setUser(user) {
  State.currentUser = user;
  const loginBtn = qs('#nav-login-btn');
  loginBtn.innerHTML = `<i class="ti ti-user-check" aria-hidden="true"></i> ${user.name.split(' ')[0]}`;
  loginBtn.onclick = handleLogout;
}

async function handleLogout() {
  try { await API.post('auth.php', 'logout'); } catch (_) {}
  State.currentUser = null;
  State.interestIds.clear();
  qs('#nav-login-btn').innerHTML = `<i class="ti ti-user" aria-hidden="true"></i> Login`;
  qs('#nav-login-btn').onclick = () => openModal('auth-modal');
  qs('#stat-interested').textContent = 0;
  renderCards();
  toast('Logged out.');
}

async function loadInterestIds() {
  if (!State.currentUser) return;
  try {
    const res = await API.get('interest.php', { action: 'ids' });
    if (res.success) {
      State.interestIds = new Set(res.data.map(Number));
      renderCards();
    }
  } catch (_) {}
}

/* =====================================================
   STATIC FALLBACK DATA (used when PHP not available)
   ===================================================== */
const DEMO_DATA = [
  {id:1,name:'Green Leaf PG',city:'Bengaluru',area:'Koramangala',price:9500,gender:'Girls',rating:4.5,description:'Cozy girls PG in the heart of Koramangala with homely food.',image_emoji:'🏠',amenities:[{name:'WiFi',icon:'📶'},{name:'Food',icon:'🍱'},{name:'Laundry',icon:'👕'},{name:'Security',icon:'🔒'}]},
  {id:2,name:'Sky Heights Hostel',city:'Mumbai',area:'Andheri West',price:11000,gender:'Boys',rating:4.2,description:'Modern amenities for working professionals and students.',image_emoji:'🏢',amenities:[{name:'WiFi',icon:'📶'},{name:'AC',icon:'❄️'},{name:'Gym',icon:'💪'},{name:'Parking',icon:'🚗'}]},
  {id:3,name:'Sunrise Residency',city:'Pune',area:'Kothrud',price:7500,gender:'Co-ed',rating:4.0,description:'Budget-friendly co-ed PG with great study environment.',image_emoji:'🏡',amenities:[{name:'WiFi',icon:'📶'},{name:'Food',icon:'🍱'},{name:'Water 24/7',icon:'💧'},{name:'Study Room',icon:'📚'}]},
  {id:4,name:'Royal Stay PG',city:'Delhi',area:'Laxmi Nagar',price:8000,gender:'Boys',rating:3.9,description:'Well-maintained PG with 24/7 security near metro.',image_emoji:'🏬',amenities:[{name:'WiFi',icon:'📶'},{name:'TV',icon:'📺'},{name:'Housekeeping',icon:'🧹'},{name:'Security',icon:'🔒'}]},
  {id:5,name:'Comfort Zone PG',city:'Hyderabad',area:'Madhapur',price:10500,gender:'Girls',rating:4.7,description:'Premium girls PG near Hitech City with AC rooms.',image_emoji:'🏘',amenities:[{name:'WiFi',icon:'📶'},{name:'AC',icon:'❄️'},{name:'Food',icon:'🍱'},{name:'Laundry',icon:'👕'},{name:'Gym',icon:'💪'}]},
  {id:6,name:'Urban Nest',city:'Bengaluru',area:'HSR Layout',price:13000,gender:'Co-ed',rating:4.3,description:'Upscale co-ed PG with power backup and gym.',image_emoji:'🏗',amenities:[{name:'WiFi',icon:'📶'},{name:'AC',icon:'❄️'},{name:'Food',icon:'🍱'},{name:'Power Backup',icon:'🔋'},{name:'Gym',icon:'💪'}]},
  {id:7,name:'Campus View PG',city:'Pune',area:'Hadapsar',price:6500,gender:'Boys',rating:3.8,description:'Affordable PG for students near IT hubs.',image_emoji:'🏰',amenities:[{name:'WiFi',icon:'📶'},{name:'Study Room',icon:'📚'},{name:'Security',icon:'🔒'},{name:'Water 24/7',icon:'💧'}]},
  {id:8,name:'Pink Blossom PG',city:'Bengaluru',area:'Indiranagar',price:12000,gender:'Girls',rating:4.6,description:'Elegant girls PG with daily housekeeping.',image_emoji:'🏛',amenities:[{name:'WiFi',icon:'📶'},{name:'AC',icon:'❄️'},{name:'Food',icon:'🍱'},{name:'Laundry',icon:'👕'},{name:'Housekeeping',icon:'🧹'}]},
  {id:9,name:'Metro Stay',city:'Delhi',area:'Dwarka',price:7000,gender:'Co-ed',rating:4.1,description:'Near metro with ample parking and good connectivity.',image_emoji:'🛖',amenities:[{name:'WiFi',icon:'📶'},{name:'TV',icon:'📺'},{name:'Parking',icon:'🚗'},{name:'Security',icon:'🔒'}]},
  {id:10,name:"Scholar's Inn",city:'Mumbai',area:'Powai',price:14000,gender:'Girls',rating:4.8,description:'Premium accommodation near IIT Bombay.',image_emoji:'🏟',amenities:[{name:'WiFi',icon:'📶'},{name:'AC',icon:'❄️'},{name:'Food',icon:'🍱'},{name:'Gym',icon:'💪'},{name:'Study Room',icon:'📚'},{name:'Power Backup',icon:'🔋'}]},
  {id:11,name:'Bharat Lodge',city:'Hyderabad',area:'Kukatpally',price:5500,gender:'Boys',rating:3.6,description:'Budget boys PG with basic amenities.',image_emoji:'🏪',amenities:[{name:'WiFi',icon:'📶'},{name:'Water 24/7',icon:'💧'},{name:'Security',icon:'🔒'}]},
  {id:12,name:'The Social PG',city:'Bengaluru',area:'BTM Layout',price:11500,gender:'Co-ed',rating:4.4,description:'Vibrant co-ed community PG with social events.',image_emoji:'🏩',amenities:[{name:'WiFi',icon:'📶'},{name:'AC',icon:'❄️'},{name:'Laundry',icon:'👕'},{name:'Gym',icon:'💪'},{name:'TV',icon:'📺'},{name:'Food',icon:'🍱'}]},
];

/* =====================================================
   INIT
   ===================================================== */
document.addEventListener('DOMContentLoaded', async () => {

  // Try PHP first; fall back to demo data
  try {
    const res = await API.get('properties.php', { action: 'list', sort: 'rating' });
    if (res.success) {
      State.properties = res.data;
      State.filtered   = res.data;
    } else throw new Error();
  } catch (_) {
    State.properties = DEMO_DATA;
    State.filtered   = [...DEMO_DATA];
  }

  qs('#stat-props').textContent  = State.properties.length;
  qs('#result-count').textContent = State.filtered.length;
  renderCards();

  // Check if already logged in (session)
  try {
    const me = await API.get('auth.php', { action: 'me' });
    if (me.success) { setUser(me.user); loadInterestIds(); }
  } catch (_) {}

  // ---- Event bindings ----

  // Search (debounced AJAX)
  let debounce;
  qs('#search-input').addEventListener('input', () => {
    clearTimeout(debounce);
    debounce = setTimeout(fetchAndRender, 350);
  });
  qs('#btn-search').addEventListener('click', fetchAndRender);
  qs('#search-input').addEventListener('keydown', e => { if (e.key === 'Enter') fetchAndRender(); });

  // Filters
  qs('#filter-city').addEventListener('change', fetchAndRender);
  qs('#filter-budget').addEventListener('change', fetchAndRender);
  qs('#sort-select').addEventListener('change', e => {
    State.sortMode = e.target.value;
    fetchAndRender();
  });

  // Gender tags
  qsa('.filter-tag').forEach(tag => {
    tag.addEventListener('click', () => setGenderFilter(tag.dataset.gender, tag));
  });

  // Nav buttons
  qs('#nav-login-btn').addEventListener('click', () => openModal('auth-modal'));
  qs('#nav-shortlist-btn').addEventListener('click', openShortlistModal);

  // Detail modal close
  qs('#close-detail').addEventListener('click', () => closeModal('detail-modal'));
  qs('#detail-modal').addEventListener('click', e => {
    if (e.target === qs('#detail-modal')) closeModal('detail-modal');
  });

  // Auth modal close
  qs('#close-auth').addEventListener('click', () => closeModal('auth-modal'));
  qs('#auth-modal').addEventListener('click', e => {
    if (e.target === qs('#auth-modal')) closeModal('auth-modal');
  });

  // Auth tabs
  qsa('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchAuthTab(btn.dataset.tab));
  });

  // Auth forms
  qs('#login-form').addEventListener('submit', handleLogin);
  qs('#signup-form').addEventListener('submit', handleSignup);

  // Shortlist modal close
  qs('#close-shortlist').addEventListener('click', () => closeModal('shortlist-modal'));
  qs('#shortlist-modal').addEventListener('click', e => {
    if (e.target === qs('#shortlist-modal')) closeModal('shortlist-modal');
  });

  // Escape key closes any open modal
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      ['detail-modal','auth-modal','shortlist-modal'].forEach(id => closeModal(id));
    }
  });
});
