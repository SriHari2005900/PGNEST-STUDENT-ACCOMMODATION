<?php
require_once 'config.php';

$db     = getDB();
$action = $_GET['action'] ?? '';
$input  = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($action) {

    // POST /php/auth.php?action=signup
    case 'signup':
        $name  = trim($input['name']  ?? '');
        $email = trim($input['email'] ?? '');
        $phone = trim($input['phone'] ?? '');
        $pass  = $input['password']   ?? '';

        if (!$name || !$email || !$pass) {
            jsonResponse(['success'=>false,'message'=>'Name, email, and password are required.'], 400);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['success'=>false,'message'=>'Invalid email address.'], 400);
        }
        if (strlen($pass) < 6) {
            jsonResponse(['success'=>false,'message'=>'Password must be at least 6 characters.'], 400);
        }

        // Check duplicate
        $stmt = $db->prepare("SELECT id FROM users WHERE email = :email");
        $stmt->execute([':email' => $email]);
        if ($stmt->fetch()) {
            jsonResponse(['success'=>false,'message'=>'This email is already registered.'], 409);
        }

        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $stmt = $db->prepare("INSERT INTO users (name, email, password, phone) VALUES (:n,:e,:p,:ph)");
        $stmt->execute([':n'=>$name,':e'=>$email,':p'=>$hash,':ph'=>$phone]);
        $uid = $db->lastInsertId();

        $_SESSION['user_id']   = $uid;
        $_SESSION['user_name'] = $name;

        jsonResponse(['success'=>true,'message'=>'Account created!','user'=>['id'=>$uid,'name'=>$name,'email'=>$email]]);
        break;

    // POST /php/auth.php?action=login
    case 'login':
        $email = trim($input['email'] ?? '');
        $pass  = $input['password']   ?? '';

        if (!$email || !$pass) {
            jsonResponse(['success'=>false,'message'=>'Email and password are required.'], 400);
        }

        $stmt = $db->prepare("SELECT id, name, email, password FROM users WHERE email = :email");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($pass, $user['password'])) {
            jsonResponse(['success'=>false,'message'=>'Invalid email or password.'], 401);
        }

        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_name'] = $user['name'];

        unset($user['password']);
        jsonResponse(['success'=>true,'message'=>'Logged in!','user'=>$user]);
        break;

    // POST /php/auth.php?action=logout
    case 'logout':
        session_destroy();
        jsonResponse(['success'=>true,'message'=>'Logged out.']);
        break;

    // GET /php/auth.php?action=me
    case 'me':
        $uid = getUserId();
        if (!$uid) jsonResponse(['success'=>false,'message'=>'Not logged in.'], 401);
        $stmt = $db->prepare("SELECT id, name, email, phone FROM users WHERE id = :id");
        $stmt->execute([':id'=>$uid]);
        $user = $stmt->fetch();
        jsonResponse(['success'=>true,'user'=>$user]);
        break;

    default:
        jsonResponse(['success'=>false,'message'=>'Unknown action.'], 400);
}
