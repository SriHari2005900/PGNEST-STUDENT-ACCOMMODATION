<?php
require_once 'config.php';

$db = getDB();
$action = $_GET['action'] ?? 'list';

switch ($action) {

    // GET /php/properties.php?action=list&city=&budget=&gender=&search=
    case 'list':
        $city   = $_GET['city']   ?? '';
        $gender = $_GET['gender'] ?? '';
        $budget = $_GET['budget'] ?? '';
        $search = $_GET['search'] ?? '';
        $sort   = $_GET['sort']   ?? 'rating';

        $where = ['1=1'];
        $params = [];

        if ($city) {
            $where[] = 'p.city = :city';
            $params[':city'] = $city;
        }
        if ($gender) {
            $where[] = 'p.gender = :gender';
            $params[':gender'] = $gender;
        }
        if ($search) {
            $where[] = '(p.name LIKE :search OR p.city LIKE :search OR p.area LIKE :search)';
            $params[':search'] = '%' . $search . '%';
        }
        if ($budget) {
            $parts = explode('-', $budget);
            if (count($parts) === 2) {
                $where[] = 'p.price BETWEEN :pmin AND :pmax';
                $params[':pmin'] = (float)$parts[0];
                $params[':pmax'] = (float)$parts[1];
            }
        }

        $orderBy = match($sort) {
            'price-asc'  => 'p.price ASC',
            'price-desc' => 'p.price DESC',
            'name'       => 'p.name ASC',
            default      => 'p.rating DESC',
        };

        $sql = "SELECT p.*, 
                    GROUP_CONCAT(a.name ORDER BY a.name SEPARATOR '|') AS amenities,
                    GROUP_CONCAT(a.icon ORDER BY a.name SEPARATOR '|') AS amenity_icons
                FROM properties p
                LEFT JOIN property_amenities pa ON pa.property_id = p.id
                LEFT JOIN amenities a ON a.id = pa.amenity_id
                WHERE " . implode(' AND ', $where) . "
                GROUP BY p.id
                ORDER BY $orderBy";

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        // Format amenities
        foreach ($rows as &$row) {
            $names = $row['amenities'] ? explode('|', $row['amenities']) : [];
            $icons = $row['amenity_icons'] ? explode('|', $row['amenity_icons']) : [];
            $row['amenities'] = array_map(fn($n,$i) => ['name'=>$n,'icon'=>$i], $names, $icons);
            unset($row['amenity_icons']);
            $row['price'] = (float)$row['price'];
            $row['rating'] = (float)$row['rating'];
        }

        jsonResponse(['success' => true, 'data' => $rows, 'count' => count($rows)]);
        break;

    // GET /php/properties.php?action=detail&id=1
    case 'detail':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonResponse(['success'=>false,'message'=>'Invalid ID'], 400);

        $stmt = $db->prepare("SELECT p.*, 
            GROUP_CONCAT(a.name ORDER BY a.name SEPARATOR '|') AS amenities,
            GROUP_CONCAT(a.icon ORDER BY a.name SEPARATOR '|') AS amenity_icons
            FROM properties p
            LEFT JOIN property_amenities pa ON pa.property_id = p.id
            LEFT JOIN amenities a ON a.id = pa.amenity_id
            WHERE p.id = :id GROUP BY p.id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();

        if (!$row) jsonResponse(['success'=>false,'message'=>'Not found'], 404);

        $names = $row['amenities'] ? explode('|', $row['amenities']) : [];
        $icons = $row['amenity_icons'] ? explode('|', $row['amenity_icons']) : [];
        $row['amenities'] = array_map(fn($n,$i) => ['name'=>$n,'icon'=>$i], $names, $icons);
        unset($row['amenity_icons']);
        $row['price'] = (float)$row['price'];
        $row['rating'] = (float)$row['rating'];

        // Check if current user is interested
        $uid = getUserId();
        $row['user_interested'] = false;
        if ($uid) {
            $s2 = $db->prepare("SELECT id FROM interested_users WHERE user_id=:u AND property_id=:p");
            $s2->execute([':u'=>$uid,':p'=>$id]);
            $row['user_interested'] = (bool)$s2->fetch();
        }

        jsonResponse(['success' => true, 'data' => $row]);
        break;

    // GET /php/properties.php?action=cities
    case 'cities':
        $stmt = $db->query("SELECT DISTINCT city FROM properties ORDER BY city");
        jsonResponse(['success'=>true,'data'=>$stmt->fetchAll(PDO::FETCH_COLUMN)]);
        break;

    default:
        jsonResponse(['success'=>false,'message'=>'Unknown action'], 400);
}
