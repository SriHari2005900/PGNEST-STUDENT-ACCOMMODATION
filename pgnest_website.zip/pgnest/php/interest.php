<?php
require_once 'config.php';

$db     = getDB();
$action = $_GET['action'] ?? '';
$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$uid    = getUserId();

switch ($action) {

    // POST /php/interest.php?action=toggle  body: {property_id: 1}
    case 'toggle':
        if (!$uid) jsonResponse(['success'=>false,'message'=>'Please login first.'], 401);

        $pid = (int)($input['property_id'] ?? 0);
        if (!$pid) jsonResponse(['success'=>false,'message'=>'Invalid property.'], 400);

        // Check if exists
        $stmt = $db->prepare("SELECT id FROM interested_users WHERE user_id=:u AND property_id=:p");
        $stmt->execute([':u'=>$uid,':p'=>$pid]);
        $existing = $stmt->fetch();

        if ($existing) {
            $db->prepare("DELETE FROM interested_users WHERE user_id=:u AND property_id=:p")
               ->execute([':u'=>$uid,':p'=>$pid]);
            jsonResponse(['success'=>true,'interested'=>false,'message'=>'Removed from interested.']);
        } else {
            $db->prepare("INSERT INTO interested_users (user_id, property_id) VALUES (:u,:p)")
               ->execute([':u'=>$uid,':p'=>$pid]);
            jsonResponse(['success'=>true,'interested'=>true,'message'=>'Marked as interested!']);
        }
        break;

    // GET /php/interest.php?action=list
    case 'list':
        if (!$uid) jsonResponse(['success'=>false,'message'=>'Please login.'], 401);

        $stmt = $db->prepare("SELECT p.*, iu.created_at AS interested_at,
            GROUP_CONCAT(a.name ORDER BY a.name SEPARATOR '|') AS amenities,
            GROUP_CONCAT(a.icon ORDER BY a.name SEPARATOR '|') AS amenity_icons
            FROM interested_users iu
            JOIN properties p ON p.id = iu.property_id
            LEFT JOIN property_amenities pa ON pa.property_id = p.id
            LEFT JOIN amenities a ON a.id = pa.amenity_id
            WHERE iu.user_id = :u
            GROUP BY p.id ORDER BY iu.created_at DESC");
        $stmt->execute([':u'=>$uid]);
        $rows = $stmt->fetchAll();

        foreach ($rows as &$row) {
            $names = $row['amenities'] ? explode('|', $row['amenities']) : [];
            $icons = $row['amenity_icons'] ? explode('|', $row['amenity_icons']) : [];
            $row['amenities'] = array_map(fn($n,$i) => ['name'=>$n,'icon'=>$i], $names, $icons);
            unset($row['amenity_icons']);
            $row['price'] = (float)$row['price'];
            $row['rating'] = (float)$row['rating'];
        }

        jsonResponse(['success'=>true,'data'=>$rows,'count'=>count($rows)]);
        break;

    // GET /php/interest.php?action=ids  — returns array of property IDs user is interested in
    case 'ids':
        if (!$uid) jsonResponse(['success'=>true,'data'=>[]]);
        $stmt = $db->prepare("SELECT property_id FROM interested_users WHERE user_id=:u");
        $stmt->execute([':u'=>$uid]);
        $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
        jsonResponse(['success'=>true,'data'=>array_map('intval',$ids)]);
        break;

    default:
        jsonResponse(['success'=>false,'message'=>'Unknown action.'], 400);
}
