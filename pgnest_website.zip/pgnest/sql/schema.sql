-- PGNest Student Accommodation Database Schema
-- Run this file in phpMyAdmin or MySQL CLI: mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS pgnest CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pgnest;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Properties table
CREATE TABLE IF NOT EXISTS properties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    city VARCHAR(100) NOT NULL,
    area VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    gender ENUM('Boys','Girls','Co-ed') NOT NULL,
    rating DECIMAL(3,1) DEFAULT 0.0,
    description TEXT,
    image_emoji VARCHAR(10) DEFAULT '🏠',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Amenities table
CREATE TABLE IF NOT EXISTS amenities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(10) DEFAULT ''
);

-- Property Amenities (junction)
CREATE TABLE IF NOT EXISTS property_amenities (
    property_id INT NOT NULL,
    amenity_id INT NOT NULL,
    PRIMARY KEY (property_id, amenity_id),
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
    FOREIGN KEY (amenity_id) REFERENCES amenities(id) ON DELETE CASCADE
);

-- Interested Users
CREATE TABLE IF NOT EXISTS interested_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    property_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_interest (user_id, property_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
);

-- =====================
-- SEED DATA
-- =====================

INSERT INTO amenities (name, icon) VALUES
('WiFi','📶'),('AC','❄️'),('Food','🍱'),('Laundry','👕'),
('Gym','💪'),('Parking','🚗'),('Water 24/7','💧'),('Security','🔒'),
('TV','📺'),('Study Room','📚'),('Housekeeping','🧹'),('Power Backup','🔋');

INSERT INTO properties (name, city, area, price, gender, rating, description, image_emoji) VALUES
('Green Leaf PG','Bengaluru','Koramangala',9500,'Girls',4.5,'Cozy girls PG in the heart of Koramangala with homely food and a warm community.','🏠'),
('Sky Heights Hostel','Mumbai','Andheri West',11000,'Boys',4.2,'Modern amenities for working professionals and students near the metro station.','🏢'),
('Sunrise Residency','Pune','Kothrud',7500,'Co-ed',4.0,'Budget-friendly co-ed PG with great study environment and 24/7 water supply.','🏡'),
('Royal Stay PG','Delhi','Laxmi Nagar',8000,'Boys',3.9,'Well-maintained PG with 24/7 security near metro station and market.','🏬'),
('Comfort Zone PG','Hyderabad','Madhapur',10500,'Girls',4.7,'Premium girls PG near Hitech City with all modern facilities and AC rooms.','🏘'),
('Urban Nest','Bengaluru','HSR Layout',13000,'Co-ed',4.3,'Upscale co-ed PG in HSR Layout with power backup, gym and rooftop terrace.','🏗'),
('Campus View PG','Pune','Hadapsar',6500,'Boys',3.8,'Affordable PG for students near IT hubs with dedicated study rooms.','🏰'),
('Pink Blossom PG','Bengaluru','Indiranagar',12000,'Girls',4.6,'Elegant girls PG in Indiranagar with daily housekeeping and laundry service.','🏛'),
('Metro Stay','Delhi','Dwarka',7000,'Co-ed',4.1,'Near metro with ample parking, good connectivity and 24/7 security.','🛖'),
('Scholar''s Inn','Mumbai','Powai',14000,'Girls',4.8,'Premium girls accommodation near IIT Bombay with top-notch facilities.','🏟'),
('Bharat Lodge','Hyderabad','Kukatpally',5500,'Boys',3.6,'Budget boys PG with basic amenities near colleges and bus stops.','🏪'),
('The Social PG','Bengaluru','BTM Layout',11500,'Co-ed',4.4,'Vibrant co-ed community PG with recreational spaces and social events.','🏩');

-- Assign amenities to properties
-- Property 1 (Green Leaf): WiFi, Food, Laundry, Security
INSERT INTO property_amenities VALUES (1,1),(1,3),(1,4),(1,8);
-- Property 2 (Sky Heights): WiFi, AC, Gym, Parking
INSERT INTO property_amenities VALUES (2,1),(2,2),(2,5),(2,6);
-- Property 3 (Sunrise): WiFi, Food, Water, Study Room
INSERT INTO property_amenities VALUES (3,1),(3,3),(3,7),(3,10);
-- Property 4 (Royal Stay): WiFi, TV, Housekeeping, Security
INSERT INTO property_amenities VALUES (4,1),(4,9),(4,11),(4,8);
-- Property 5 (Comfort Zone): WiFi, AC, Food, Laundry, Gym
INSERT INTO property_amenities VALUES (5,1),(5,2),(5,3),(5,4),(5,5);
-- Property 6 (Urban Nest): WiFi, AC, Food, Power Backup, Gym
INSERT INTO property_amenities VALUES (6,1),(6,2),(6,3),(6,12),(6,5);
-- Property 7 (Campus View): WiFi, Study Room, Security, Water
INSERT INTO property_amenities VALUES (7,1),(7,10),(7,8),(7,7);
-- Property 8 (Pink Blossom): WiFi, AC, Food, Laundry, Housekeeping
INSERT INTO property_amenities VALUES (8,1),(8,2),(8,3),(8,4),(8,11);
-- Property 9 (Metro Stay): WiFi, TV, Parking, Security
INSERT INTO property_amenities VALUES (9,1),(9,9),(9,6),(9,8);
-- Property 10 (Scholar's Inn): WiFi, AC, Food, Gym, Study Room, Power Backup
INSERT INTO property_amenities VALUES (10,1),(10,2),(10,3),(10,5),(10,10),(10,12);
-- Property 11 (Bharat Lodge): WiFi, Water, Security
INSERT INTO property_amenities VALUES (11,1),(11,7),(11,8);
-- Property 12 (The Social): WiFi, AC, Laundry, Gym, TV, Food
INSERT INTO property_amenities VALUES (12,1),(12,2),(12,4),(12,5),(12,9),(12,3);

-- Demo user (password: password123)
INSERT INTO users (name, email, password, phone) VALUES
('Demo Student','demo@pgnest.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','9876543210');
